import React from 'react';

import classes from './Navigation.module.css';
import {
  Link
} from "react-router-dom";
const Navigation = (props) => {
  return (
    <nav className="navbar navbar-expand-lg  navbar-dark bg-dark">
    <div className="container-fluid">
      {/* <a className="navbar-brand" href="#">HighChart</a> */}
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarText">
        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
          {/* <li className="nav-item"> */}
           
            {/* <a className="nav-link active" aria-current="page" href="#"> */}
            <Link  className="nav-link active" to={`/`}>
              Pie
              </Link>
              {/* </a> */}
              <Link  className="nav-link"  to={`/line`}>
              Line
              </Link>
              <Link  className="nav-link" to={`/column`}>
              Column
              </Link>
              <Link  className="nav-link" to={`/donutchart`}>
              Donut
              </Link>
            
          {/* </li>
          <li className="nav-item">
            <a className="nav-link" href="#">Line</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">Pie</a>
          </li> */}
        </ul>
        <span className="navbar-text">
         HighChart Examples using React
        </span>
      </div>
    </div>
  </nav>
  );
};

export default Navigation;
