
import React from 'react';
import ColumnChart from './charts/ColumnChart';
import MainHeader from './components/MainHeader/MainHeader';
import PieChart from './charts/pieChart';
import LineChart from './charts/lineChart';
import DonutChart from './charts/donutChart';

// import {BrowserRouter as Router} from 'react-router-dom'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

function App() {

  const pieData = [{
    name: 'Covid +ve',
    y: 40
  }, {
    name: 'Covid -ve',
    y: 30
  }, {
    name: 'Recovered',
    y: 20
  }, {
    name: 'Reinfected',
    y: 5
  }, {
    name: 'Other',
    y: 5
  }];

  const lineChart = {
    title: {
      text: "Line Chart"
    },
    xAxis: {
      type: "datetime"
    },
    series: [
      {
        data: [[1, 2], [2, 4], [3, 2]],
        type: "line"
      }
    ]
  };

  return (
    <React.Fragment>
    {/* <MainHeader/> */}
    <Router>
    <MainHeader/>

    <div>
    <div className="text-center">
    
    <h2 className="fw-bold">HighCharts</h2>
    <div className="col-lg-6 mx-auto">
      <p className="mb-4">HighCharts using React js</p>
      
    </div>
  </div>


    </div>
    <main>
     <Switch>
          <Route exact path="/line"
          render={(props) => (
              <LineChart {...props} chartOptions={lineChart}/>
            )}
          
          >
          {/* <h1>Line</h1> */}
          </Route>
          <Route exact
            path='/'
            render={(props) => (
              <PieChart {...props} pieData={pieData} type="pie"/>
            )}
          />
          
          <Route exact path="/column" component={ColumnChart}>
          </Route>
          <Route exact path="/donutchart" component={DonutChart}>
          </Route>
          
        </Switch>
    </main>
    </Router>
  </React.Fragment>
    // <div>
    //   <ColumnChart></ColumnChart>
    // </div>
  );
}

export default App;
