import ReactDOM from 'react-dom';

import './index.css';
import App from './App';
import * as bootstrap from 'bootstrap';


ReactDOM.render(<App />, document.getElementById('root'));
