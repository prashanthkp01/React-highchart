import React from "react";
import { render } from "react-dom";
// Import Highcharts
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";

class LineChart extends React.Component {
    constructor(props) {
        super(props);
      }

      render() {
        return (
           
            <HighchartsReact
            highcharts={Highcharts}
            options={this.props.chartOptions}
          />
        
        )}
}

export default LineChart;