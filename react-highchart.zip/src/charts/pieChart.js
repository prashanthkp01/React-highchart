import React from "react";
import { render } from "react-dom";
// Import Highcharts
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";

require("highcharts/modules/exporting")(Highcharts);
require("highcharts/modules/accessibility")(Highcharts);
Highcharts.setOptions({
  colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4']
});
class PieChart extends React.Component {

  static formatTooltip(tooltip, x = this.key, y = this.y, series = this.series) {
    console.log(this,"this")
    return `<b>${x}</b><br/>${y}%`;
  }
    constructor(props) {
        super(props);
      }
      render() {
        return (
           
            <HighchartsReact
            highcharts={Highcharts}
            
            options={{
              chart: {
                type: this.props.type
              },
              tooltip: {
      formatter: PieChart.formatTooltip,
    },

              title:{
                  text:"Pie Chart"
              },
              subtitle:{
                  text:"Data from props,Tooltip formated,custom colors"
              },
              
              series: [
                {
                  data: this.props.pieData
                  
                }
                
              ]
            }}
          />
        
        )}

        

}

export default PieChart;