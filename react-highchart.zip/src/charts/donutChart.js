import React from "react";
import { render } from "react-dom";
// Import Highcharts
import Highcharts from "highcharts";
import variablePie from "highcharts/modules/variable-pie.js";
//import HighchartsReact from "./HighchartsReact.js";
import HighchartsReact from "highcharts-react-official";

variablePie(Highcharts);

const options = {
  chart: {
    // renderTo: 'container',
    type: "variablepie",
    margin: [0, 0, 0, 0],
    // marginLeft: -100,
    events: {
      load: function() {
        this.renderer
          .circle(
            this.chartWidth / 2,
            this.plotHeight / 2 + this.plotTop,
            this.plotHeight / 4
          )
          .attr({
            fill: "rgba(0,0,0,0)",
            stroke: "#2ec277",
            left: -100,
            "stroke-width": 1
          })
          .add();
      }
    }
  },
  colors: ["#2ec277", "#2db799", "#b7e886", "#6d5494", "#0077b4"],

  title: {
    text: null
  },

  legend: {
    align: "right",
    verticalAlign: "top",
    layout: "vertical",
    x: 0,
    y: 60,
    itemMarginTop: 5,
    itemMarginBottom: 5,
    itemStyle: {
    //   font: "17pt Trebuchet MS, Verdana, sans-serif",
      color: "#333333"
    }
  },
  plotOptions: {
    series: {
      stacking: "normal",
      dataLabels: {
        enabled: false
      },
      showInLegend: true,
      size: 185
    }
  },

  series: [
    {
      minPointSize: 10,
      innerSize: "27%",
      zMin: 0,
      name: "Job Match",
      data: [
        {
          name: "React js  35%",
          y: 100,
          z: 35
        },
        {
          name: "Vue js 34%",
          y: 100,
          z: 34
        }, {
            name: "Angular 31%",
            y: 100,
            z: 31
          }
      ]
    }
  ]
};
class DonutChart extends React.Component {

  
    constructor(props) {
        super(props);
      }
      render() {
        return (
           
            <HighchartsReact
          highcharts={Highcharts}
          options={options}
          ref="chartComponent1"
        />
        
        )}

        

}

export default DonutChart;