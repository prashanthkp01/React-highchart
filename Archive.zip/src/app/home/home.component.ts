import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalpopupComponent } from '../modalpopup/modalpopup.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  showpopup=false;
  event_list = [
    {
      event:' Event 1',
      eventLocation:'Best IT Training Center In Hyderabad',
      eventDescription:'BEST SOFTWARE TRAINING INSTITUTE.',
      img: 'https://www.incimages.com/uploaded_files/image/1940x900/getty_933383882_2000133420009280345_410292.jpg'
      
    },
     {
      event:' Event 2',
      eventLocation:'',
      eventDescription:'EXCELLENT AND FRIENDLY FACULTY MEMBERS',
      img: 'https://www.incimages.com/uploaded_files/image/1940x900/getty_933383882_2000133420009280345_410292.jpg'
     
    }
  ]

  // upcoming_events =  this.event_list.filter( event => event.eventStartDate > new Date());
  // past_events = this.event_list.filter(event => event.eventEndingDate < new Date());
  // current_events =  this.event_list.filter( event => (event.eventStartDate >= new Date() && (event.eventEndingDate <= new Date())))
  constructor(private modalService: NgbModal) {
    
  }
  ngOnInit() {
      }

    ngAfterViewInit() {this.modalService.open(ModalpopupComponent);}


}
