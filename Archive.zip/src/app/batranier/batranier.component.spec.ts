import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatranierComponent } from './batranier.component';

describe('BatranierComponent', () => {
  let component: BatranierComponent;
  let fixture: ComponentFixture<BatranierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatranierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatranierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
