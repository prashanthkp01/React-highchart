import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-batranier',
  templateUrl: './batranier.component.html',
  styleUrls: ['./batranier.component.css']
})
export class BatranierComponent implements OnInit {
  tranierform: FormGroup;
  formErrors = {
    'email': '',
    'firstName': '',
    'phoneNumber': '',
    'technology': '',
    'comments':''
  };
  
  validationMessages = {
    'phoneNumber': {
      'required': 'Phone number is mandatory',
      'pattern': 'Please provide valid phone number.',
      'minlength': 'Minimum length allowed 10',
      'maxlength': 'Maxlength length allowed 10'
    },
    'firstName': {
      'required': 'Name is mandatory',
      'pattern': 'Please enter only (space,alphabets)',
      'minlength': 'Minimum length allowed 2',
      'maxlength': 'Maxlength length allowed 16'
    },
    'comments': {
      
      'maxlength': 'Please enter max 250 characters.'
    },
    'email': {
      'required': 'Email is required.',
      'pattern': 'Please provide valid Email'
    },
    'technology': {
      //'required': 'Course is mandatory',
    }
  };
  constructor(public formBuilder: FormBuilder,
    private router: Router,) { }

  ngOnInit() {

    this.tranierform = this.formBuilder.group({
      // email: ['', [Validators.required, Validators.email]],
      phoneNumber: new FormControl('', [
        Validators.required,
        Validators.pattern(/^(?![0]*$)\d{1,8}(?:\d{1,2})?$/),
        Validators.minLength(10),
        Validators.maxLength(10)
      ]),
      firstName: new FormControl('', [
        Validators.required,
        Validators.pattern(/^[a-zA-Z\s]+$/),
        Validators.minLength(2),
        Validators.maxLength(16)  
      ]),
      technology: new FormControl('', [
        //Validators.required
      ]),
      comments: new FormControl('', [
        Validators.maxLength(250)
      ]),
      email: new FormControl('', [
        Validators.required,
        Validators.pattern(/^(([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\w+\-+)|(\w+\.))*\w{1,63}\.[a-zA-Z]{2,6}$/)
      ])
    });
    this.tranierform.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.tranierform);
    
    });
  }
  logValidationErrors(group: FormGroup = this.tranierform): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';
        if (abstractControl && !abstractControl.valid
          && (abstractControl.touched || abstractControl.dirty)) {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }
      }
    });
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // convenience getter for easy access to form fields
  get f() { return this.tranierform.controls; }

  trainerSubmit(){
 if (this.tranierform.invalid) {
      return;
    }
    console.log(this.f.firstName.value)
    console.log(this.f)
  }

}
