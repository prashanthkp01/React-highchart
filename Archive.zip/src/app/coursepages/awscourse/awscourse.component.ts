import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-awscourse',
  templateUrl: './awscourse.component.html',
  styleUrls: ['./awscourse.component.css']
})
export class AwscourseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
