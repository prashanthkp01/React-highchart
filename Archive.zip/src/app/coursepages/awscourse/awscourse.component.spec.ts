import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AwscourseComponent } from './awscourse.component';

describe('AwscourseComponent', () => {
  let component: AwscourseComponent;
  let fixture: ComponentFixture<AwscourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AwscourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AwscourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
