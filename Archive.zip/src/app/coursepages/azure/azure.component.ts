import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-azure',
  templateUrl: './azure.component.html',
  styleUrls: ['./azure.component.css']
})
export class AzureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
