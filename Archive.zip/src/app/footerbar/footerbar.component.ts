import { Component, OnInit, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-footerbar',
  templateUrl: './footerbar.component.html',
  styleUrls: ['./footerbar.component.css']
})
export class FooterbarComponent implements OnInit {

  constructor(@Inject(DOCUMENT) private dom: Document) { }

  ngOnInit() {
  }
 goTop(){
  this.dom.body.scrollTop =0;
  this.dom.documentElement.scrollTop=0;
 }
}
