import { Component, OnInit, Input } from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-modalpopup',
  templateUrl: './modalpopup.component.html',
  styleUrls: ['./modalpopup.component.css']
})
export class ModalpopupComponent implements OnInit {
  @Input() type;
  title="Moshk Tranings";

  newbatch = [
    {
    date: "07-05-2020",
    course: "Python Training",
    time: "07:30 AM",
    id:'2',
    trainer: "Mr. Srinivas",
    duration: "60 Hours	",
    register: "Enroll"
    },
    {
      date: "09-05-2020",
      course: "AWS Training",
      id:'2',
      courseId:"AWS",
      time: "08:30 AM",
      trainer: "Mr. Bhaskar",
      duration: "60 Hours	",
      register: "Enroll"
    }
    
  ];
  constructor(public activeModal: NgbActiveModal) { }
  ngOnInit() {
    if(this.type === 'Enquire'){
this.title ="Course Enquiry";
    }
  }


}
