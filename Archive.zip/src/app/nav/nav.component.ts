import { Component, OnInit } from '@angular/core';
import { ModalpopupComponent } from '../modalpopup/modalpopup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }
  openEnquire(){
    const modalRef = this.modalService.open(ModalpopupComponent);
    modalRef.componentInstance.type = 'Enquire';
  }
}
