import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router, ActivatedRoute } from '@angular/router';
import { DataServiceService } from '../service/data-service.service';
import { PersistanceService } from '../service/persistance-service.service';
interface bactch {
  date: string;
  course: string;
  location: string;
  mode: string;
  time: string;
  trainer: string;
  duration: string;
  register: string;
}

const BATCHES = [
  {
    date: "07-05-2020",
  course: "Python Training",
  courseId:"Phython",
  location: "Online",
  mode: "Online",
  time: "07:30 AM",
  trainer: "Mr. Srinivas",
  duration: "45 Hours	",
  register: "Enroll",
  enrollDetails:{
    img:'',
    courseDetails:{

    },
    trainerDetails:{

    }
  }
  },
  {
    date: "07-05-2020",
    course: "AWS Training",
    location: "Online",
    courseId:"AWS",
    mode: "Online",
    time: "07:30 AM",
    trainer: "Mr. Bhaskar",
    duration: "45 Hours	",
    register: "Enroll"
  }
  
];
@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})

export class CoursesComponent implements OnInit {
  courseDetails: any = [];
  batches = BATCHES;
  constructor(private httpClient: HttpClient,private route: ActivatedRoute,
    private router: Router,
    private persistanceService: PersistanceService,
    public dataservice: DataServiceService) { }

  ngOnInit() {
    this.httpClient.get("../assets/data/coursedata.json").subscribe(data =>{
      console.log(data);
      this.courseDetails = data;
    })
  }
  onGoToEnroll(cls){
    this.router.navigate(['/enroll'], { queryParams: { course: cls.courseId } }); 
    // goProducts() {
    //   this.router.navigate(['/products'], { queryParams: { order: 'popular', 'price-range': 'not-cheap' } });
    // }
    this.persistanceService.set("enrollData", cls);
    this.dataservice.enrollData = cls; 
  }

}
