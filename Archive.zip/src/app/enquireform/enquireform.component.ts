import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-enquireform',
  templateUrl: './enquireform.component.html',
  styleUrls: ['./enquireform.component.css']
})
export class EnquireformComponent implements OnInit {
  enquireForm: FormGroup;
  coursesavl;
  constructor(private httpClient: HttpClient,private formBuilder: FormBuilder,) { }
  formErrors = {
    'email': '',
    'firstName': '',
    'phoneNumber': '',
    'courses': ''
  };
  
  validationMessages = {
    'phoneNumber': {
      'required': 'Phone number is mandatory',
      'pattern': 'Please provide valid phone number.',
      'minlength': 'Minimum length allowed 10',
      'maxlength': 'Maxlength length allowed 10'
    },
    'firstName': {
      'required': 'Name is mandatory',
      'pattern': 'Please enter only (space,alphabets)',
      'minlength': 'Minimum length allowed 2',
      'maxlength': 'Maxlength length allowed 16'
    },
    'email': {
      'required': 'Email is required.',
      'pattern': 'Please provide valid Email'
    },
    'courses': {
      'required': 'Course is mandatory',
    },
  };
  ngOnInit() {

    
    this.httpClient.get("../assets/data/courselist.json").subscribe(data =>{
      console.log(data);
      this.coursesavl = data;
    });
   
    this.enquireForm = this.formBuilder.group({
      // email: ['', [Validators.required, Validators.email]],
      phoneNumber: new FormControl('', [
        Validators.required,
        Validators.pattern(/^(?![0]*$)\d{1,8}(?:\d{1,2})?$/),
        Validators.minLength(10),
        Validators.maxLength(10)
      ]),
      firstName: new FormControl('', [
        Validators.required,
        Validators.pattern(/^[a-zA-Z\s]+$/),
        Validators.minLength(2),
        Validators.maxLength(16)  
      ]),
      courses: new FormControl('', [
        Validators.required
      ]),
      email: new FormControl('', [
        Validators.required,
        Validators.pattern(/^(([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\w+\-+)|(\w+\.))*\w{1,63}\.[a-zA-Z]{2,6}$/)
      ])
    });
    this.enquireForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.enquireForm);
    });
    
  }
  logValidationErrors(group: FormGroup = this.enquireForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';
        if (abstractControl && !abstractControl.valid
          && (abstractControl.touched || abstractControl.dirty)) {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }
      }
    });
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // convenience getter for easy access to form fields
  get f() { return this.enquireForm.controls; }

  onSubmit() {
    if (this.enquireForm.invalid) {
      return;
    }
    console.log(this.f.firstName.value)
    console.log(this.f)
  }
}
