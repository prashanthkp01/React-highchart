import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnquireformComponent } from './enquireform.component';

describe('EnquireformComponent', () => {
  let component: EnquireformComponent;
  let fixture: ComponentFixture<EnquireformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnquireformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnquireformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
