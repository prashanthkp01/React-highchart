import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CoursesComponent } from './courses/courses.component';
import { OnlinetraningComponent } from './onlinetraning/onlinetraning.component';
import {  EnrollPageComponent } from './enroll-page/enroll-page.component';
import { BatranierComponent} from './batranier/batranier.component'

const routes: Routes = [
  {path: '', redirectTo: '/home', pathMatch: 'full'},
  { path: 'about-us', component: AboutComponent },
  { path: 'home', component: HomeComponent },
  { path: 'courses', component: CoursesComponent },
  { path: 'new-batches', component: OnlinetraningComponent },
  { path: 'contact', component: ContactUsComponent },
  { path: 'enroll', component: EnrollPageComponent },
  {path:'become-a-tranier', component: BatranierComponent}
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
