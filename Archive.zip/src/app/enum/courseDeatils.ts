export enum CourseDetails {
    AWS='<p></p>'+
    '<h2 style="text-align:justify"><span style="color:#000080"><strong><span style="font-size:16px">'+
    '<span style="font-family:verdana,geneva,sans-serif">what is python?</span></span></strong></span></h2>'+
    '<p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
    '<span style="color:#000000">Python is an interpreted high-level programming language for general-purpose programming.'+
    '<br>Python\'s simple, easy to learn syntax emphasizes readability and therefore reduces the cost of program maintenance.</span></span></span></p>'+
    '<h1 style="text-align:justify"><strong><span style="color:#000080"><span style="font-size:16px">'+
   '<span style="font-family:verdana,geneva,sans-serif">About Python Course:</span></span></span></strong>'+
    '</h1><p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
    '<span style="color:#000000">Python is powerful and fast; plays well with others; runs everywhere; is friendly'+
                    '&amp; easy to learn; is open. Python is programming language that lets you work more quickly and'+
                    'integrate your systems more effectively. &nbsp;</span></span></span></p>'+
    '<p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
    '<span style="color:#000000">There is a Python framework for pretty much anything, from web apps to data'+
                   'analysis. Python is often heralded as the easiest programming language to learn, with its simple and'+
                    'straightforward syntax. Python has risen in popularity due to Google\'s investment in it over the past'+
                    'decade.</span></span></span></p>'+
    '<h2 style="text-align:justify"><span style="color:#000080"><span'+
                'style="font-family:verdana,geneva,sans-serif"><strong><span class="htmltext">who can learn python?'+
                        '</span></strong></span></span></h2>'+
    '<p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
    '<span style="color:#000000">Have a computer (either Mac, Windows, or Linux)<br>Basic to Intermediate Python'+
                    'Skills<br>Basic math skills.<br>Those who are showing interest to build their career in Python<br>IT'+
                    'Developers<br>Big Data ProfessionalsDesire to learn!</span></span></span></p>'+
    '<h3><span style="color:#000080"><span style="font-size:16px"><strong><span'+
                        'style="font-family:verdana,geneva,sans-serif">What Will I Learn?</span></strong></span></span></h3>'+
    '<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#000000">1.Use'+
                    'the Jupyter Notebook Environment.<br>2.Have an intermediate skill level of Python programming.numpy'+
                    'library to create and manipulate arrays.<br>3.Use the pandas module with Python to create and structure'+
                    'data.<br>4.Learn how to work with various data formats within python,including: JSON,HTML, and MS Excel'+
                    'Worksheets.<br>5.Create data visualizations usingmatplotlib and the seaborn modules with'+
                    'python.<br>6.Have a portfolio of various data analysis projects.</span></span></span></p>'+
    '<h2 style="text-align:justify"><span style="color:#000080"><strong><span style="font-size:16px"><span'+
                        'style="font-family:verdana,geneva,sans-serif">what are prerequisites for Python'+
                        'Training?</span></span></strong></span></h2>'+
    '<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#000000">There'+
                    'are no hard pre-requisites. Basic understanding of Computer Programming terminologies is sufficient.'+
                    'Also, basic concepts related to Programming and Database is beneficial but not'+
                    'mandatory.</span></span></span></p>'+
    '<p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#000000">Python'+
                    'function<br>importing external modules<br>understanding of Python Path concepts<br>operators and'+
                    'loops<br>string manipulation operations<br>object-oriented concepts.<br>Learn REST APIs and'+
                    'JSON<br>Database Management and SQL queriessyntax of the Python</span></span></span></p>'+
    '<h2 style="text-align:justify"><span style="color:#000080"><span style="font-size:16px"><strong><span'+
                        'style="font-family:verdana,geneva,sans-serif">who are the target audience for'+
                        'python?</span></strong></span></span></h2>'+
    '<p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span'+
                    'style="color:#000000">JAVA programmers<br>Testing Engineers<br>Networking professional<br>Engineering'+
                    'and Computer Science Students<br>Fresher’s</span></span></span></p>'+
    '<h2 style="text-align:justify"><span style="color:#000080"><strong><span style="font-size:16px"><span'+
                        'style="font-family:verdana,geneva,sans-serif">what we provide in our'+
                        'training?</span></span></strong></span></h2>'+
    '<p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span'+
                    'style="color:#000000">Keynotes During Training<br>Real Time Project Studies<br>Soft copy'+
                    'materials<br>Flexible Timings<br>Affordable Cost<br>Trainer Support<br>Technical Support<br>Certificate'+
                    'of Completion</span></span></span><br>&nbsp;</p>'+
                    '<p></p>',
//     AWS =  '<div class="content">' +
//     '<h1 style="color:#000080">This is a heading</h1>' +
//     '<p>This is a paragraph of text.</p>' +
//     '<p><strong>Note:</strong> If you don\'t escape "quotes" properly, it will not work.</p>' +
// '</div>'+
//     // AWS = `<p></p>
//     '<h2 style="text-align:justify">'+
//    '<span style="color:#000080"><strong>'+
//     '<span style="font-size:16px">'+
//     '<span style="font-family:verdana,geneva,sans-serif">what is AWS?</span>'+
//     '</span>'+
//     '</strong></span>'+
//     '</h2><p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif">'+
//     '<span style="font-size:14px"><span style="color:#000000">'+
//     'AWS is an interpreted high-level programming language for general-purpose programming.'+
//     '<br>Python\'s simple, easy to learn syntax emphasizes readability and therefore reduces the cost of program maintenance.</span></span></span></p><h1 style="text-align:justify"><strong><span style="color:#000080"><span style="font-size:16px"><span style="font-family:verdana,geneva,sans-serif">About Python Course:</span></span></span></strong></h1><p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><span style="color:#000000">Python is powerful and fast; plays well with others; runs everywhere; is friendly &amp; easy to learn; is open. Python is programming language that lets you work more quickly and integrate your systems more effectively. &nbsp;</span></span></span></p><p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
//     '<span style="color:#000000">There is a Python framework for pretty much anything, from web apps to data analysis. Python is often heralded as the easiest programming language to learn, with its simple and straightforward syntax. Python has risen in popularity due to '+
//     'Google\'s investment in it over the past decade.</span></span></span></p><h2 style="text-align:justify"><span style="color:#000080"><span style="font-family:verdana,geneva,sans-serif"><strong><span class="htmltext">who can learn python?</span></strong></span></span></h2><p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif">'+
//     '<span style="font-size:14px">'+
//     '<span style="color:#000000">'+
//     'Have a computer (either Mac, Windows, or Linux)<br>Basic to Intermediate Python Skills<br>Basic math skills.<br>Those who are showing interest to build their career in Python<br>IT Developers<br>Big Data ProfessionalsDesire to learn!</span></span></span></p><h3><span style="color:#000080"><span style="font-size:16px"><strong>'+
//     '<span style="font-family:verdana,geneva,sans-serif">What Will I Learn?</span></strong></span>'+
//     '</span></h3><p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
//     '<span style="color:#000000">1.Use the Jupyter Notebook Environment.'+
//     '<br>2.Have an intermediate skill level of Python programming.numpy library to create and manipulate arrays.<br>3.Use the pandas module with Python to create and structure data.<br>4.Learn how to work with various data formats within python,including: JSON,HTML, and MS Excel Worksheets.<br>5.Create data visualizations usingmatplotlib and the seaborn modules with python.<br>6.Have a portfolio of various data analysis projects.</span></span></span></p>'+
//     '<h2 style="text-align:justify"><span style="color:#000080"><strong><span style="font-size:16px"><span style="font-family:verdana,geneva,sans-serif">what are prerequisites for Python Training?</span></span></strong></span></h2><p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
//     '<span style="color:#000000">There are no hard pre-requisites. Basic understanding of Computer Programming terminologies is sufficient. Also, basic concepts related to Programming and Database is beneficial but not mandatory.</span></span></span></p><p><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
//     '<span style="color:#000000">Python function<br>importing external modules<br>understanding of Python Path concepts<br>operators and loops<br>string manipulation operations<br>object-oriented concepts.<br>Learn REST APIs and JSON<br>Database Management and SQL queriessyntax of the Python</span></span></span>'+
//     '</p><h2 style="text-align:justify"><span style="color:#000080"><span style="font-size:16px"><strong>'+
//     '<span style="font-family:verdana,geneva,sans-serif">who are the target audience for python?</span></strong></span>'+
//     '</span></h2><p style="text-align:justify"><span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
//     '<span style="color:#000000">JAVA programmers<br>Testing Engineers<br>Networking professional<br>Engineering and '+
//     'Computer Science Students<br>Fresher’s</span></span></span></p><h2 style="text-align:justify">'+
//     '<span style="color:#000080"><strong><span style="font-size:16px"><span style="font-family:verdana,geneva,sans-serif">'+
    
//     'what we provide in our training?</span></span></strong></span></h2><p style="text-align:justify">'+
//     '<span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px">'+
//     '<span style="color:#000000">Keynotes During Training<br>Real Time Project Studies<br>Soft copy materials<br>Flexible Timings<br>Affordable Cost<br>Trainer Support<br>Technical Support<br>Certificate of Completion</span></span></span><br>&nbsp;</p><h1 style="text-align:justify">'+
//     '<span style="font-family:verdana,geneva,sans-serif"><span style="font-size:14px"><a href="http://qshore.com/courses/python-training"><span style="color:#000000">Python training in kondapur</span></a><span style="color:#000000">|</span>'+
//     '<a href="http://qshore.com/courses/python-training"><span style="color:#000000">Python training in gachibowli</span></a><span style="color:#000000">|</span><a href="http://qshore.com/courses/python-training"><span style="color:#000000">python training in madhapur</span></a><span style="color:#000000">|</span><a href="http://qshore.com/courses/python-training"><span style="color:#000000">Python training in&nbsp;</span></a><a href="http://Python training in&nbsp;Hyderabad"><span style="color:#000000">Hyderabad</span></a><span style="color:#000000">|</span><a href="http://qshore.com/courses/python-training"><span style="color:#000000">Python Online training</span>'+
//     '</a></span></span></h1><p></p>',
    NOTFOUND = 'NOTFOUND',
    MULTIPLEMATCH = 'MULTIPLEMATCH'
  }