import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CourseDetails} from '../enum/courseDeatils'
import { Subscription } from 'rxjs';
import "../../assets/data/model";
import { DataServiceService } from '../service/data-service.service'
import { PersistanceService } from '../service/persistance-service.service';

@Component({
  selector: 'app-enroll-page',
  templateUrl: './enroll-page.component.html',
  styleUrls: ['./enroll-page.component.css']
})
export class EnrollPageComponent implements OnInit {
  pageid:any;
  enrollPageData:any;
  sub: Subscription; 
  coursedtls:any; 
  pageName;
  newdata;
//   data=[
//     {
//         "config":{
//             "id":"AWS",
//             "img":"./assests/img/aws.jpg"
//         },
//         "content":[
//                 {
//                     "heading":"what is python?",
//                     "paragraph1":"Python is an interpreted high-level programming language for general-purpose programming.",
//                     "paragraph2":"Python's simple, easy to learn syntax emphasizes readability and therefore reduces the cost of program maintenance."
//                 },{
//                     "heading":"About Python Course:",
//                     "paragraph1":"Python is powerful and fast; plays well with others; runs everywhere; is friendly & easy to learn; is open. Python is programming language that lets you work more quickly and integrate your systems more effectively. ",
//                     "paragraph2":"There is a Python framework for pretty much anything, from web apps to data analysis. Python is often heralded as the easiest programming language to learn, with its simple and straightforward syntax. Python has risen in popularity due to Google's investment in it over the past decade."
//                 },{
//                     "heading":"who can learn python?",
//                     "span1":"Have a computer (either Mac, Windows, or Linux)",
//                     "span2":"Basic to Intermediate Python Skills",
//                     "span3":"Basic math skills.",
//                     "span4":"Those who are showing interest to build their career in Python",
//                     "span5":"IT Developers",
//                     "span6":"Big Data ProfessionalsDesire to learn!"
//                 }
//         ]

//     }

// ]
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private persistanceService: PersistanceService,
    public dataservice: DataServiceService) {}

    ngOnInit() {
      // this.sub= this.route
      //   .queryParams
      //   .subscribe(params => {
      //     // Defaults to 0 if no query param provided.
      //     this.pageid = params['course'] || 0;
      //     console.log('Query param page: ', this.pageid);
      //   });
        console.log(window)
        this.enrollPageData = this.dataservice.enrollData;
        const enDta=this.persistanceService.get("enrollData")
        console.log(enDta,"enDta")
        console.log(this.enrollPageData,"enroll")
        if(enDta){
          this.coursedtls = enDta;
           // console.log(this.data)
        // this.newdata= this.data[0].content
            this.pageName = enDta.courseId;
             this.newdata= CourseDetails.AWS;
          
        }
        
        
    }
    ngOnDestroy() {
     // this.dataservice.enrollData = ""; 
      //this.sub.unsubscribe();
    }

  //   content:{
  //     what:[
  //         {
  //             heading:"what is",
  //             paragraph:"Python is an interpreted high-level programming language for general-purpose programming.",
  //             paragraph:"Python's simple, easy to learn syntax emphasizes readability and therefore reduces the cost of program maintenance."
  //         }
  //     ],
  //     about:[
  //         {
  //             heading
  //         }
  //     ],
  //     who:[

  //     ],
  //     whatiklearn:[

  //     ],
  //     prerequisites:[

  //     ],
  //     targetaudience:[

  //     ],
  //     weprovide:[

  //     ]
  // }

}
