import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestinomalsComponent } from './testinomals.component';

describe('TestinomalsComponent', () => {
  let component: TestinomalsComponent;
  let fixture: ComponentFixture<TestinomalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestinomalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestinomalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
