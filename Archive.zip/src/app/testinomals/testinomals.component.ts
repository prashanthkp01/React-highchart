import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testinomals',
  templateUrl: './testinomals.component.html',
  styleUrls: ['./testinomals.component.css']
})
export class TestinomalsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
