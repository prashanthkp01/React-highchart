import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestcall',
  templateUrl: './requestcall.component.html',
  styleUrls: ['./requestcall.component.css']
})
export class RequestcallComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
