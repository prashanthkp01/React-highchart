import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {HttpClientModule }  from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { OnlinetraningComponent } from './onlinetraning/onlinetraning.component';
import { CoursesComponent } from './courses/courses.component';
import { NewBatcheslistComponent } from './new-batcheslist/new-batcheslist.component';
import { EnrollPageComponent } from './enroll-page/enroll-page.component';
import { CurriculumComponent } from './curriculum/curriculum.component';

import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { RequestcallComponent } from './requestcall/requestcall.component';
import { ListofcoursesComponent } from './listofcourses/listofcourses.component';
import { FooterbarComponent } from './footerbar/footerbar.component';
import { SearchPipe } from './search.pipe';
import { ModalpopupComponent } from './modalpopup/modalpopup.component';
import { EnquireformComponent } from './enquireform/enquireform.component';
import { AwscourseComponent } from './coursepages/awscourse/awscourse.component';
import { DevopsComponent } from './coursepages/devops/devops.component';
import { AzureComponent } from './coursepages/azure/azure.component';
import { PhythonComponent } from './coursepages/phython/phython.component';
import { TestinomalsComponent } from './testinomals/testinomals.component';
import { BatranierComponent } from './batranier/batranier.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    AboutComponent,
    HomeComponent,
    ContactUsComponent,
    OnlinetraningComponent,
    CoursesComponent,
    NewBatcheslistComponent,
    EnrollPageComponent,
    CurriculumComponent,
    RequestcallComponent,
    ListofcoursesComponent,
    FooterbarComponent,
    SearchPipe,
    ModalpopupComponent,
    EnquireformComponent,
    AwscourseComponent,
    DevopsComponent,
    AzureComponent,
    PhythonComponent,
    TestinomalsComponent,
    BatranierComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFontAwesomeModule,
    HttpClientModule,
    NgbModule.forRoot()
  ],
  entryComponents: [ModalpopupComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
