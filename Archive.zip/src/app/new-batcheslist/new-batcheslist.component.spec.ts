import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewBatcheslistComponent } from './new-batcheslist.component';

describe('NewBatcheslistComponent', () => {
  let component: NewBatcheslistComponent;
  let fixture: ComponentFixture<NewBatcheslistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewBatcheslistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewBatcheslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
