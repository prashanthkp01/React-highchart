import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-batcheslist',
  templateUrl: './new-batcheslist.component.html',
  styleUrls: ['./new-batcheslist.component.css']
})
export class NewBatcheslistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
