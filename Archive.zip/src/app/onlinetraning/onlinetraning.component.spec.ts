import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlinetraningComponent } from './onlinetraning.component';

describe('OnlinetraningComponent', () => {
  let component: OnlinetraningComponent;
  let fixture: ComponentFixture<OnlinetraningComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlinetraningComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlinetraningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
