import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataServiceService } from '../service/data-service.service';
import { PersistanceService } from '../service/persistance-service.service';
interface bactch {
  date: string;
  course: string;
  location: string;
  mode: string;
  time: string;
  trainer: string;
  duration: string;
  register: string;
}

const BATCHES = [
  {
    date: "07-05-2020",
  course: "Python Training",
  courseId:"Phython",
  location: "Online",
  id:'1',
  mode: "Online",
  time: "07:30 AM",
  trainer: "Mr. Srinivas",
  duration: "45 Hours	",
  register: "Enroll",
  enrollDetails:{
    img:'',
    courseDetails:{

    },
    trainerDetails:{

    }
  }
  },
  {
    date: "09-05-2020",
    course: "AWS Training",
    location: "Online",
    id:'2',
    courseId:"AWS",
    mode: "offline",
    time: "08:30 AM",
    trainer: "Mr. Bhaskar",
    duration: "60 Hours	",
    register: "Enroll"
  },
  {
    date: "09-05-2020",
    course: "Azure Training",
    location: "Online",
    id:'3',
    courseId:"Azure",
    mode: "offline",
    time: "08:30 AM",
    trainer: "Mr. Bhaskar",
    duration: "60 Hours	",
    register: "Enroll"
  },
  {
    date: "09-05-2020",
    course: "DevOps Training",
    location: "Online",
    id:'3',
    courseId:"DevOps",
    mode: "offline",
    time: "08:30 AM",
    trainer: "Mr. Bhaskar",
    duration: "60 Hours	",
    register: "Enroll"
  }
  
];
@Component({
  selector: 'app-onlinetraning',
  templateUrl: './onlinetraning.component.html',
  styleUrls: ['./onlinetraning.component.css']
})
export class OnlinetraningComponent implements OnInit {
  batches = BATCHES;
  searchText="";
  constructor(private route: ActivatedRoute,
    private router: Router,
    public dataservice: DataServiceService,
    private persistanceService: PersistanceService) { }

  ngOnInit() {
  }
  onGoToEnroll(cls){
    this.router.navigate(['/enroll'], { queryParams: { course: cls.courseId } }); 
    // goProducts() {
    //   this.router.navigate(['/products'], { queryParams: { order: 'popular', 'price-range': 'not-cheap' } });
    // }
    this.persistanceService.set("enrollData", cls);
    this.dataservice.enrollData = cls; 
  }

  ngOnDestroy() {
    
  }
  //routerLink="/enroll" [queryParams]="{ course: cls.courseId  }"

}
